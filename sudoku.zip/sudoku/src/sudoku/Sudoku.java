
package sudoku;

import java.util.*;
import java.awt.event.*;
import javax.swing.*;


public class Sudoku extends JFrame implements MouseListener
{
    
    public static ImageIcon boardi;
    public static JLabel boardl;
    
    public static ImageIcon numi[] = new ImageIcon[9];
    public static JLabel numl[] = new JLabel[9];
    
    public static ImageIcon boldi[] = new ImageIcon[9];
    
    public static ImageIcon bluei;
    public static JLabel bluel;
    
    public static JLabel box[][] = new JLabel[9][9];
    
    public static int way[] = new int[9];
    
    public static String initial[] = new String[9];
    
    public static boolean isBold[][] = new boolean[9][9];
    
    public static int content[][] = new int[9][9];
    
    public static int blueCurrentX;
    public static int blueCurrentY;
    
    public static boolean winFlag;
    
    public static JPanel panel = new JPanel();

    public Sudoku()
    {
        setSize(500,500);
        setLayout(null);
        setVisible(true);
        setTitle("sudoku");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel.setLayout(null);
        
        setContentPane(panel);
        
        boardi = new ImageIcon(getClass().getResource("image\\board.jpg"));
        boardl = new JLabel(boardi);
        
        boardl.setBounds(50,50,900,900);
        
        panel.add(boardl);
        
        for(int i=0;i<9;i++)
        {
            numi[i] = new ImageIcon(getClass().getResource("image\\"+(i+1)+".png"));
            numl[i] = new JLabel(numi[i]);
            
            numl[i].setBounds(1000,50+(i*100),100,100);
            panel.add(numl[i]);
            
            boldi[i] = new ImageIcon(getClass().getResource("image\\"+(i+1)+"b.png"));
        }
        
        
        
        set();
        bluei = new ImageIcon(getClass().getResource("image\\blue.png"));
        bluel = new JLabel(bluei);
        bluel.setBounds(way[0],way[0],100,100);
        panel.add(bluel);
        panel.add(boardl);
        blueCurrentX = 0;
        blueCurrentY = 0;
        
        winFlag=false;
        
        addMouseListener(this);
    }
    
    public static void set()
    {
        
        initial[0] = "034070010";
        initial[1] = "600190348";
        initial[2] = "098002567";
        initial[3] = "850761023";
        initial[4] = "426803701";
        initial[5] = "010924850";
        initial[6] = "901030204";
        initial[7] = "007409635";
        initial[8] = "005286079";
        
        for(int i=0;i<9;i++)
        {
            way[i] = 50 + (i*100);
        }
        
        for(int i=0;i<9;i++)
        {
            for(int j=0;j<9;j++)
            {
                box[i][j] = new JLabel();
                box[i][j].setBounds(way[j],way[i],100,100);
                panel.add(box[i][j]);
                
                isBold[i][j] = false;
                
                content[i][j] = -1;
                
                if(initial[i].charAt(j)!='0')
                {
                    int temp = Integer.parseInt(String.valueOf(initial[i].charAt(j)));
                    temp--;
                    box[i][j].setIcon(boldi[temp]);
                    
                    isBold[i][j] = true;
                    
                    content[i][j] = temp;
                }
            }
        }
        
        
        
    }
    
    public static void moveBlue(int x,int y)
    {
        int i = (x-50)/100;
        int j = (y-50)/100;
        
        bluel.setBounds(way[i],way[j],100,100);
        blueCurrentX = i;
        blueCurrentY = j;
    }
    
    public static void change(int y)
    {
        int piece = (y-50)/100;
        
        box[blueCurrentY][blueCurrentX].setIcon(numi[piece]);
        
        content[blueCurrentY][blueCurrentX] = piece;
        
        checkFill();
    }
    
    public static void checkFill()
    {
        boolean flag = true;
        
        for(int i=0;i<9;i++)
        {
            for(int j=0;j<9;j++)
            {
                if(content[i][j]==-1)
                {
                    flag = false;
                    break;
                }
            }
        }
        
        if(flag)
        {
            checkContent();
        }
    }
    
    public static void checkContent()
    {
        boolean flag = true;
        
        for(int i=0;i<9;i++)
        {
            for(int j=0;j<9;j++)
            {
                for(int k=j+1;k<9;k++)
                {
                    if(content[i][j]==content[i][k] || content[j][i]==content[k][i])
                    {
                        flag = false;
                        break;
                    }
                }
                if(flag==false)
                {
                    break;
                }
            }
            if(flag==false)
            {
                break;
            }
        }
        
        if(flag)
        {
            for(int i=0;i<3;i++)
            {
                for(int j=0;j<3;j++)
                {
                    flag=checkComplex(i,j);
                    if(flag==false)
                    {
                        break;
                    }
                }
                if(flag==false)
                {
                    break;
                }
            }
        }
        
        if(flag)
        {
            winFlag=true;
            
            for(int i=0;i<9;i++)
            {
                panel.remove(numl[i]);
            }
            panel.revalidate();
            panel.repaint();
        }
    }
    
    public static boolean checkComplex(int x,int y)
    {
        int temp[] = new int[9];
        boolean flag=true;
        
        for(int i=0;i<3;i++)
        {
            for(int j=0;j<3;j++)
            {
                temp[ (i*3) + j ] = content[ (x*3) + i ][ (y*3) + j ];
            }
        }
        
        for(int i=0;i<9;i++)
        {
            for(int j=i+1;j<9;j++)
            {
                if(temp[i]==temp[j])
                {
                    flag=false;
                    break;
                }
            }
            if(flag==false)
            {
                break;
            }
        }
        
        return flag;
    }
    
    public static void main(String[] args) 
    {
        Sudoku s = new Sudoku();
    }

    @Override
    public void mouseClicked(MouseEvent e) 
    {
        int x = e.getX();
        int y = e.getY();
        
        if(winFlag==false)
        {
            if(x>50 && x<950 && y>50 && y<950)
            {
                moveBlue(x,y);
            }
            else if(x>1000 && x<1100 && y>50 && y<950)
            {
                if(!isBold[blueCurrentY][blueCurrentX])
                {
                    change(y);
                }
            }
        }
    }

    @Override
    public void mousePressed(MouseEvent e) 
    {}

    @Override
    public void mouseReleased(MouseEvent e) 
    {}

    @Override
    public void mouseEntered(MouseEvent e) 
    {}

    @Override
    public void mouseExited(MouseEvent e) 
    {}
    
}
