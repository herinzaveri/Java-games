
package puzzle;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Puzzle extends JFrame implements MouseListener
{
    
    ImageIcon image[] = new ImageIcon[9];
    public static JLabel l[] = new JLabel[9];
    ImageIcon wi = new ImageIcon();
    public static JLabel wl = new JLabel();
    
    public static JPanel panel = new JPanel();
    
    public static int imageAtPlace[] = new int[9];
    public static int currentPlace[] = new int[9];
    public static int empty;
    public static int emptyx;
    public static int emptyy;
    public static int x[] = new int[9];
    public static int y[] = new int[9];
    public static int positionx[] = new int[9];
    public static int positiony[] = new int[9];
    public static int win;
    
    Puzzle()
    {
        setSize(500,500);
        setLayout(null);
        setVisible(true);
        setTitle("puzzle");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel.setLayout(null);
        setContentPane(panel);
        
        addMouseListener(this);
        
        win=1;
        
        int i;
        
        empty=4;
        emptyx=510;
        emptyy=220;
        
        wi = new ImageIcon(getClass().getResource("image\\10.jpg"));
        wl = new JLabel(wi);
        wl.setBounds(300,10,600,600);
        
        for(i=0;i<9;i++)
        {
            image[i] = new ImageIcon(getClass().getResource("image\\"+(i+1)+".jpg"));
            l[i] = new JLabel(image[i]);
        }
        x[0]=720;
        y[0]=220;
        x[1]=300;
        y[1]=220;
        x[2]=720;
        y[2]=10;
        x[3]=720;
        y[3]=430;
        x[4]=510;
        y[4]=10;
        x[5]=300;
        y[5]=10;
        x[6]=300;
        y[6]=430;
        x[7]=510;
        y[7]=430;
        
        imageAtPlace[0]=5;
        currentPlace[5]=0;
        imageAtPlace[1]=4;
        currentPlace[4]=1;
        imageAtPlace[2]=2;
        currentPlace[2]=2;
        imageAtPlace[3]=1;
        currentPlace[1]=3;
        imageAtPlace[5]=0;
        currentPlace[0]=5;
        imageAtPlace[6]=6;
        currentPlace[6]=6;
        imageAtPlace[7]=7;
        currentPlace[7]=7;
        imageAtPlace[8]=3;
        currentPlace[3]=8;
        
        positionx[0]=300;
        positiony[0]=10;
        positionx[1]=510;
        positiony[1]=10;
        positionx[2]=720;
        positiony[2]=10;
        positionx[3]=300;
        positiony[3]=220;
        positionx[4]=510;
        positiony[4]=220;
        positionx[5]=720;
        positiony[5]=220;
        positionx[6]=300;
        positiony[6]=430;
        positionx[7]=510;
        positiony[7]=430;
        positionx[8]=720;
        positiony[8]=430;
        
        for(i=0;i<8;i++)
        {
            l[i].setBounds(x[i],y[i],200,200);
            panel.add(l[i]);
        }
        
    }
    
    public static void moveLeft(int a)
    {
        x[a]-=210;
        l[a].setBounds(x[a],y[a],200,200);
        panel.revalidate();
        empty=currentPlace[a];
        emptyx+=210;
        currentPlace[a]-=1;
        imageAtPlace[currentPlace[a]]=a;
    }
    public static void moveRight(int a)
    {
        x[a]+=210;
        l[a].setBounds(x[a],y[a],200,200);
        panel.revalidate();
        empty=currentPlace[a];
        emptyx-=210;
        currentPlace[a]+=1;
        imageAtPlace[currentPlace[a]]=a;
    }
    public static void moveUp(int a)
    {
        y[a]-=210;
        l[a].setBounds(x[a],y[a],200,200);
        panel.revalidate();
        empty=currentPlace[a];
        emptyy+=210;
        currentPlace[a]-=3;
        imageAtPlace[currentPlace[a]]=a;
    }
    public static void moveDown(int a)
    {
        y[a]+=210;
        l[a].setBounds(x[a],y[a],200,200);
        panel.revalidate();
        empty=currentPlace[a];
        emptyy-=210;
        currentPlace[a]+=3;
        imageAtPlace[currentPlace[a]]=a;
    }
    
    public static void click(int x,int y)
    {
        int n=0;
        if(y>10&&y<210)
        {
            if(x>300&&x<500)
            {
                n=0;
            }
            else if(x>510&&x<710)
            {
                n=1;
            }
            else if(x>720&&x<920)
            {
                n=2;
            }
        }
        else if(y>220&&y<420)
        {
            if(x>300&&x<500)
            {
                n=3;
            }
            else if(x>510&&x<710)
            {
                n=4;
            }
            else if(x>720&&x<920)
            {
                n=5;
            }
        }
        else if(y>430&&y<630)
        {
            if(x>300&&x<500)
            {
                n=6;
            }
            else if(x>510&&x<710)
            {
                n=7;
            }
            else if(x>720&&x<920)
            {
                n=8;
            }
        }
        
        
        
        
        if(emptyx==positionx[n])
        {
            if(empty-n==-3)
            {
                moveUp(imageAtPlace[n]);
            }
            else if(empty-n==3)
            {
                moveDown(imageAtPlace[n]);
            }
        }
        else if(emptyy==positiony[n])
        {
            if(empty-n==-1)
            {
                moveLeft(imageAtPlace[n]);
            }
            else if(empty-n==1)
            {
                moveRight(imageAtPlace[n]);
            }
        }
    }
    
    public static void win()
    {
        int i;
        
        for(i=0;i<8;i++)
        {
            if(imageAtPlace[i]==i)
            {
                win=0;
            }
            else
            {
                win=1;
                break;
            }
        }
        
        if(win==0)
        {
            
            
            panel.removeAll();
            panel.add(wl);
        }
    }

    
    public static void main(String[] args) 
    {
        Puzzle p = new Puzzle();
    }

    @Override
    public void mouseClicked(MouseEvent e)
    {
        int x = e.getX();
        int y = e.getY();
        
        
        click(x,y);
        panel.revalidate();
        this.repaint();
        
        win();
        panel.revalidate();
        this.repaint();
        
    }

    @Override
    public void mousePressed(MouseEvent e)
    {}

    @Override
    public void mouseReleased(MouseEvent e)
    {}

    @Override
    public void mouseEntered(MouseEvent e)
    {}

    @Override
    public void mouseExited(MouseEvent e)
    {}
    
}
