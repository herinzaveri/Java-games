
package snake;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class Snake extends JFrame implements MouseListener
{
    
    ImageIcon boardi;
    JLabel boardl;
    
    public static ImageIcon bluei,greeni;
    public static JLabel bluel,greenl;
    
    public static ImageIcon dicei[] = new ImageIcon[6];
    public static JLabel dicel;
    
    ImageIcon rolli;
    JLabel rolll;
    
    public static ImageIcon turni[] = new ImageIcon[2];
    public static JLabel turnl;
    
    public static int wayX[] = new int[100];
    public static int wayY[] = new int[100];
    
    public static int blueCurrent;
    public static int greenCurrent;
    
    public static boolean turn;
    
    public static int dice;
    
    public static boolean diceRolled;
    
    public static int sl[] = new int[100];
    
    public static boolean win;
    
    public static JPanel panel = new JPanel();
    
    public Snake()
    {
        setSize(1000,1000);
        setLayout(null);
        setVisible(true);
        setTitle("snake");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel.setLayout(null);
        
        setContentPane(panel);
        
        boardi = new ImageIcon(getClass().getResource("image\\snake.jpg"));
        boardl = new JLabel(boardi);
        
        boardl.setBounds(100,100,750,750);
        panel.add(boardl);
        
        bluei = new ImageIcon(getClass().getResource("image\\blue.png"));
        bluel = new JLabel(bluei);
        
        greeni = new ImageIcon(getClass().getResource("image\\green.png"));
        greenl = new JLabel(greeni);
        
        bluel.setBounds(100,900,25,25);
        panel.add(bluel);
        
        greenl.setBounds(150,900,25,25);
        panel.add(greenl);
        
        panel.add(boardl);
        
        for(int i=0;i<6;i++)
        {
            dicei[i] = new ImageIcon(getClass().getResource("image\\"+(i+1)+".jpg"));
        }
        dicel = new JLabel(dicei[5]);
        dicel.setBounds(950,300,100,100);
        panel.add(dicel);
        dice=6;
        diceRolled = false;
        
        rolli = new ImageIcon(getClass().getResource("image\\roll.jpg"));
        rolll = new JLabel(rolli);
        rolll.setBounds(900,450,200,100);
        panel.add(rolll);
        
        turni[0] = new ImageIcon(getClass().getResource("image\\blue turn.jpg"));
        turni[1] = new ImageIcon(getClass().getResource("image\\green turn.jpg"));
        turnl = new JLabel(turni[0]);
        turnl.setBounds(900,600,200,100);
        panel.add(turnl);
        
        setWay();
        
        turn = true;
        
        blueCurrent = -1;
        greenCurrent = -1;
        
        win=false;
        
        addMouseListener(this);
        
    }
    
    public static void setWay()
    {
        for(int i=0;i<10;i++)
        {
            for(int j=0;j<10;j++)
            {
                wayY[(i*10)+j] = 775 - (i*75);
            }
            
            if(i%2==0)
            {
                for(int j=0;j<10;j++)
                {
                    wayX[(i*10)+j] = 100 + (j*75);
                }
            }
            else
            {
                for(int j=0;j<10;j++)
                {
                    wayX[(i*10)+j] = 775 - (j*75);
                }
            }
        }
        
        for(int i=0;i<100;i++)
        {
            sl[i] = i;
        }
        
        sl[3] = 55;
        sl[11] = 49;
        sl[13] = 54;
        sl[21] = 57;
        sl[40] = 78;
        sl[53] = 87;
        
        sl[27] = 9;
        sl[36] = 2;
        sl[46] = 17;
        sl[74] = 31;
        sl[93] = 70;
        sl[95] = 41;
    }
    
    public static void moveBlue(int d)
    {
        diceRolled = true;
        
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() 
            {
                for(int i=blueCurrent;i<=blueCurrent+d;i++)
                {
                    bluel.setBounds(wayX[i]+25,wayY[i]+25,25,25);
                    try
                    {
                        Thread.sleep(500);
                    }
                    catch(Exception e)
                    {}
                }
                blueCurrent = blueCurrent+d;
                
                if(sl[blueCurrent]!=blueCurrent)
                {
                    blueCurrent = sl[blueCurrent];
                    bluel.setBounds(wayX[blueCurrent]+25,wayY[blueCurrent]+25,25,25);
                }
                
                diceRolled = false;
                turn=false;
                turnl.setIcon(turni[1]);
                
                if(blueCurrent==99)
                {
                    win=true;
                    turnl.setIcon(turni[0]);
                }
                
            }
        });
        
        t.start();
    }
    
    public static void moveGreen(int d)
    {
        diceRolled = true;
        
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() 
            {
                for(int i=greenCurrent;i<=greenCurrent+d;i++)
                {
                    greenl.setBounds(wayX[i]+25,wayY[i]+25,25,25);
                    try
                    {
                        Thread.sleep(500);
                    }
                    catch(Exception e)
                    {}
                }
                greenCurrent = greenCurrent+d;
                
                if(sl[greenCurrent]!=greenCurrent)
                {
                    greenCurrent = sl[greenCurrent];
                    greenl.setBounds(wayX[greenCurrent]+25,wayY[greenCurrent]+25,25,25);
                }
                
                diceRolled = false;
                turn=true;
                turnl.setIcon(turni[0]);
                
                if(greenCurrent==99)
                {
                    win=true;
                    turnl.setIcon(turni[1]);
                }
                
            }
        });
        
        t.start();
    }
    
    public static int random()
    {
        Random r = new Random();
        
        int rand = 0;
        
        while(rand==0)
        {
            rand = r.nextInt(7);
        }
        
        return rand;
    }
    
    public static void roll()
    {
        dice = random();
        
        dicel.setIcon(dicei[dice-1]);
        
        if(turn==true)
        {
            if(blueCurrent==-1)
            {
                if(dice==1)
                {
                    bluel.setBounds(wayX[0]+25,wayY[0]+25,25,25);
                    blueCurrent = 0;
                }
                turn=false;
                turnl.setIcon(turni[1]);
            }
            else
            {
                if(blueCurrent+dice <= 99)
                {
                    moveBlue(dice);
                }
                else
                {
                    turn=false;
                    turnl.setIcon(turni[1]);
                }
            }
        }
        else
        {
            if(greenCurrent==-1)
            {
                if(dice==1)
                {
                    greenl.setBounds(wayX[0]+25,wayY[0]+25,25,25);
                    greenCurrent=0;
                }
                turn=true;
                turnl.setIcon(turni[0]);
            }
            else
            {
                if(greenCurrent+dice <= 99)
                {
                    moveGreen(dice);
                }
                else
                {
                    turn=true;
                    turnl.setIcon(turni[0]);
                }
            }
        }
    }

    
    public static void main(String[] args) 
    {
        Snake s = new Snake();
    }

    @Override
    public void mouseClicked(MouseEvent e) 
    {
        int x = e.getX();
        int y = e.getY();
        
        if(diceRolled==false && win==false)
        {
            if(x>900 && x<1100 && y>450 && y<550)
            {
                roll();
            }
        }
    }

    @Override
    public void mousePressed(MouseEvent e) 
    {}

    @Override
    public void mouseReleased(MouseEvent e) 
    {}

    @Override
    public void mouseEntered(MouseEvent e) 
    {}

    @Override
    public void mouseExited(MouseEvent e) 
    {}
    
}
