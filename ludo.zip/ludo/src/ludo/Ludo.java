
package ludo;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class Ludo extends JFrame implements MouseListener
{
    
    ImageIcon boardi;
    public static JLabel boardl;
    
    ImageIcon bluei;
    public static JLabel bluel[] = new JLabel[4];
    
    ImageIcon greeni;
    public static JLabel greenl[] = new JLabel[4];
    
    public static ImageIcon statusi[] = new ImageIcon[3];
    public static JLabel statusl;
    
    public static ImageIcon dicei[] = new ImageIcon[6];
    public static JLabel dicel;
    
    public static ImageIcon turni[] = new ImageIcon[2];
    public static JLabel turnl;
    
    public static int blueOriginX[] = new int[4];
    public static int blueOriginY[] = new int[4];
    public static int greenOriginX[] = new int[4];
    public static int greenOriginY[] = new int[4];
    
    public static int blueWayX[] = new int[13];
    public static int blueWayY[] = new int[13];
    public static int yellowWayX[] = new int[13];
    public static int yellowWayY[] = new int[13];
    public static int greenWayX[] = new int[13];
    public static int greenWayY[] = new int[13];
    public static int redWayX[] = new int[13];
    public static int redWayY[] = new int[13];
    
    public static int blueWinWay[] = new int[7];
    public static int greenWinWay[] = new int[7];
    
    public static int blueCurrent[][] = new int[4][5];
    public static int greenCurrent[][] = new int[4][5];
    
    public static boolean blueIsSafe[] = new boolean[4];
    public static boolean greenIsSafe[] = new boolean[4];
    
    public static boolean blueIsMovable[] = new boolean[4];
    public static boolean greenIsMovable[] = new boolean[4];
    
    public static boolean currentTurn;
    
    public static boolean diceRolled;
    
    public static int dice;
    
    public static int xBuffer = 10;
    public static int yBuffer = 40;
    
    public static JLabel temp1 = new JLabel("hello");
    public static JLabel temp2 = new JLabel("hello");
    public static JLabel temp3 = new JLabel("hello");
    
    public static JPanel panel = new JPanel();
    
    public Ludo()
    {
        setSize(500,500);
        setLayout(null);
        setVisible(true);
        setTitle("ludo");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel.setLayout(null);
        
        setContentPane(panel);
        
        boardi = new ImageIcon(getClass().getResource("image\\ludo.jpg"));
        
        boardl = new JLabel(boardi);
        
        boardl.setBounds(100,100,750,750);
        
        panel.add(boardl);
        
        bluei = new ImageIcon(getClass().getResource("image\\blue.png"));
        greeni = new ImageIcon(getClass().getResource("image\\green.png"));
        
        blueOriginX[0] = 187;
        blueOriginX[1] = 287;
        blueOriginX[2] = 187;
        blueOriginX[3] = 287;
        
        blueOriginY[0] = 637;
        blueOriginY[1] = 637;
        blueOriginY[2] = 737;
        blueOriginY[3] = 737;
        
        greenOriginX[0] = 637;
        greenOriginX[1] = 637;
        greenOriginX[2] = 737;
        greenOriginX[3] = 737;
        
        greenOriginY[0] = 187;
        greenOriginY[1] = 287;
        greenOriginY[2] = 187;
        greenOriginY[3] = 287;
        
        for(int i=0;i<4;i++)
        {
            bluel[i] = new JLabel(bluei);
            greenl[i] = new JLabel(greeni);
            
            bluel[i].setBounds(blueOriginX[i],blueOriginY[i],25,25);
            greenl[i].setBounds(greenOriginX[i],greenOriginY[i],25,25);
            
            panel.add(bluel[i]);
            panel.add(greenl[i]);
            
            for(int j=0;j<5;j++)
            {
                blueCurrent[i][j] = -1;
                greenCurrent[i][j] = -1;
            }
            
            blueIsMovable[i] = false;
            greenIsMovable[i] = false;
            
            blueIsSafe[i] = true;
            greenIsSafe[i] = true;
        }
        
        
        panel.add(boardl);
        panel.revalidate();
        
        setWay();
        
        int r = random();
        
        //moveBlue(r,3);
        
        statusi[0] = new ImageIcon(getClass().getResource("image\\roll.jpg"));
        statusi[1] = new ImageIcon(getClass().getResource("image\\rolling.jpg"));
        statusi[2] = new ImageIcon(getClass().getResource("image\\move.jpg"));
        
        statusl = new JLabel(statusi[0]);
        
        statusl.setBounds(900,500,200,100);
        
        
        for(int i=0;i<6;i++)
        {
            dicei[i] = new ImageIcon(getClass().getResource("image\\"+(i+1)+".jpg"));
            
        }
        
        dicel = new JLabel(dicei[5]);
        dicel.setBounds(950,350,100,100);
        
        panel.add(statusl);
        panel.add(dicel);
        
        turni[0] = new ImageIcon(getClass().getResource("image\\blue turn.jpg"));
        turni[1] = new ImageIcon(getClass().getResource("image\\green turn.jpg"));
        
        turnl = new JLabel(turni[0]);
        
        turnl.setBounds(900,650,200,100);
        panel.add(turnl);
        
        currentTurn = true;
        diceRolled = false;
        
        addMouseListener(this);
        
        temp1.setBounds(500,25,100,50);
        panel.add(temp1);
        
        temp2.setBounds(400,25,100,50);
        panel.add(temp2);
        
        temp3.setBounds(600,25,200,50);
        panel.add(temp3);
        
    }
    
    public static void setWay()
    {
        for(int i=0;i<5;i++)
        {
            blueWayX[i] = 400;
            blueWayY[i] = 750 - (i*50);
            
            yellowWayX[i] = 150 + (i*50);
            yellowWayY[i] = 400;
            
            greenWayX[i] = 500;
            greenWayY[i] = 150 + (i*50);
            
            redWayX[i] = 750 - (i*50);
            redWayY[i] = 500;
        }
        for(int i=5;i<11;i++)
        {
            blueWayX[i] = 350 - ((i-5)*50);
            blueWayY[i] = 500;
            
            yellowWayX[i] = 400;
            yellowWayY[i] = 350 - ((i-5)*50);
            
            greenWayX[i] = 550 + ((i-5)*50);
            greenWayY[i] = 400;
            
            redWayX[i] = 500;
            redWayY[i] = 550 + ((i-5)*50);
        }
        for(int i=11;i<13;i++)
        {
            blueWayX[i] = 100;
            blueWayY[i] = 450 - ((i-11)*50);
            
            yellowWayX[i] = 450 + ((i-11)*50);
            yellowWayY[i] = 100;
            
            greenWayX[i] = 800;
            greenWayY[i] = 450 + ((i-11)*50);
            
            redWayX[i] = 450 - ((i-11)*50);
            redWayY[i] = 800;
        }
        
        for(int i=0;i<7;i++)
        {
            blueWinWay[i] = 800 - (i*50);
            greenWinWay[i] = 150 + (i*50);
        }
        
    }
    
    public static void moveNewBlue(int piece)
    {
        bluel[piece].setBounds(blueWayX[0]+12,blueWayY[0]+12,25,25);
        blueCurrent[piece][0] = 0;
        blueIsMovable[piece] = true;
        diceRolled = false;
        temp3.setText("color: 0    position: "+blueCurrent[piece][0]);
    }
    
    public static void moveWinBlue(int d,int piece)
    {
        int position = blueCurrent[piece][4];
        
        for(int i=position;i<=(position+d);i++)
        {
            bluel[piece].setBounds(450+12,blueWinWay[i]+12,25,25);
        }
        blueCurrent[piece][4] = position+d;
        diceRolled = false;
        temp3.setText("color: 4    position: "+blueCurrent[piece][4]);
        
        if(blueCurrent[piece][4]!=6)
        {
            currentTurn=false;
            turnl.setIcon(turni[1]);
        }
        else
        {
            
        }
    }
    
    public static void moveBlue(int d, int piece)
    {
        boolean newFlag = true;
        int color=5,position=-1;
        int buffer=0;
        boolean killFlag = false;
        
        if(piece!=4)
        {
            for(int i=0;i<5;i++)
            {
                if(blueCurrent[piece][i]!=-1)
                {
                    newFlag = false;
                    break;
                }
            }
            

            if(newFlag==true)
            {
                if(d==6)
                {
                    moveNewBlue(piece);
                }
            }
            else if(blueCurrent[piece][4]!=-1)
            {
                if(d<=(6-blueCurrent[piece][4]))
                {
                    moveWinBlue(d,piece);
                }
            }
            else if(blueIsMovable[piece]==true)
            {
                for(int i=0;i<4;i++)
                {
                    if(blueCurrent[piece][i]!=-1)
                    {
                        color=i;
                        position=blueCurrent[piece][i];
                        break;
                    }
                }
                
                if(color!=5 && position!=-1)
                {
                    for(int i=position;i<=(position+d);i++)
                    {
                        if(color==3)
                        {
                            if(i==12)
                            {
                                blueCurrent[piece][color]=-1;
                                color++;
                                //bluel[piece].setBounds(450+12,blueWinWay[0]+12,25,25);
                                blueCurrent[piece][color]=0;
                                
                            }
                        }
                        else if(i==13)
                        {
                            blueCurrent[piece][color]=-1;
                            color++;
                            buffer=13;
                        }
                        if(color==0)
                        {
                            bluel[piece].setBounds(blueWayX[i-buffer]+12,blueWayY[i-buffer]+12,25,25);
                        }
                        else if(color==1)
                        {
                            bluel[piece].setBounds(yellowWayX[i-buffer]+12,yellowWayY[i-buffer]+12,25,25);
                        }
                        else if(color==2)
                        {
                            bluel[piece].setBounds(greenWayX[i-buffer]+12,greenWayY[i-buffer]+12,25,25);
                        }
                        else if(color==3)
                        {
                            bluel[piece].setBounds(redWayX[i-buffer]+12,redWayY[i-buffer]+12,25,25);
                        }
                        else if(color==4)
                        {
                            moveWinBlue(position+d-i+1,piece);
                            break;
                        }
                        
                    }
                    if(color!=4)
                    {
                        blueCurrent[piece][color]=position+d-buffer;
                        temp3.setText("color: "+color+"    position: "+blueCurrent[piece][color]);
                    }
                    if(blueCurrent[piece][color]==0 || blueCurrent[piece][color]==8)
                    {
                        blueIsSafe[piece] = true;
                    }
                    else
                    {
                        blueIsSafe[piece] = false;
                    }
                    killFlag = killByBlue(color,piece);
                }
            }
            
            statusl.setIcon(statusi[0]);
            diceRolled = false;
            if(d!=6)
            {
                currentTurn=false;
                turnl.setIcon(turni[1]);
                
                if(killFlag==true)
                {
                    currentTurn=true;
                    turnl.setIcon(turni[0]);
                }
            }
            else
            {
                
            }
        }
        
        
        
        
    }
    
    public static void moveNewGreen(int piece)
    {
        greenl[piece].setBounds(greenWayX[0]+12,greenWayY[0]+12,25,25);
        greenCurrent[piece][0] = 0;
        greenIsMovable[piece] = true;
        diceRolled = false;
        temp3.setText("color: 0    position: "+greenCurrent[piece][0]);
    }
    
    public static void moveWinGreen(int d,int piece)
    {
        int position = greenCurrent[piece][4];
        
        for(int i=position;i<=(position+d);i++)
        {
            greenl[piece].setBounds(450+12,greenWinWay[i]+12,25,25);
        }
        greenCurrent[piece][4] = position+d;
        diceRolled = false;
        temp3.setText("color: 4    position: "+greenCurrent[piece][4]);
        
        if(greenCurrent[piece][4]!=6)
        {
            currentTurn=false;
            turnl.setIcon(turni[1]);
        }
        else
        {
            
        }
    }
    
    public static void moveGreen(int d,int piece)
    {
        boolean newFlag = true;
        int color=5,position=-1;
        int buffer=0;
        boolean killFlag = false;
        
        if(piece!=4)
        {
            for(int i=0;i<5;i++)
            {
                if(greenCurrent[piece][i]!=-1)
                {
                    newFlag = false;
                    break;
                }
            }
            

            if(newFlag==true)
            {
                if(d==6)
                {
                    moveNewGreen(piece);
                }
            }
            else if(greenCurrent[piece][4]!=-1)
            {
                if(d<=(5-greenCurrent[piece][4]))
                {
                    moveWinGreen(d,piece);
                }
            }
            else if(greenIsMovable[piece]==true)
            {
                for(int i=0;i<4;i++)
                {
                    if(greenCurrent[piece][i]!=-1)
                    {
                        color=i;
                        position=greenCurrent[piece][i];
                        break;
                    }
                }
                
                if(color!=5 && position!=-1)
                {
                    for(int i=position;i<=(position+d);i++)
                    {
                        if(color==3)
                        {
                            if(i==12)
                            {
                                greenCurrent[piece][color]=-1;
                                color++;
                                //bluel[piece].setBounds(450+12,blueWinWay[0]+12,25,25);
                                greenCurrent[piece][color]=0;
                                
                            }
                        }
                        else if(i==13)
                        {
                            greenCurrent[piece][color]=-1;
                            color++;
                            buffer=13;
                        }
                        if(color==0)
                        {
                            greenl[piece].setBounds(greenWayX[i-buffer]+12,greenWayY[i-buffer]+12,25,25);
                        }
                        else if(color==1)
                        {
                            greenl[piece].setBounds(redWayX[i-buffer]+12,redWayY[i-buffer]+12,25,25);
                        }
                        else if(color==2)
                        {
                            greenl[piece].setBounds(blueWayX[i-buffer]+12,blueWayY[i-buffer]+12,25,25);
                        }
                        else if(color==3)
                        {
                            greenl[piece].setBounds(yellowWayX[i-buffer]+12,yellowWayY[i-buffer]+12,25,25);
                        }
                        else if(color==4)
                        {
                            moveWinGreen(position+d-i,piece);
                            break;
                        }
                        
                    }
                    if(color!=4)
                    {
                        greenCurrent[piece][color]=position+d-buffer;
                        temp3.setText("color: "+color+"    position: "+greenCurrent[piece][color]);
                    }
                    if(greenCurrent[piece][color]==0 || greenCurrent[piece][color]==8)
                    {
                        greenIsSafe[piece] = true;
                    }
                    else
                    {
                        greenIsSafe[piece] = false;
                    }
                    killFlag = killByGreen(color,piece);
                }
            }
            
            statusl.setIcon(statusi[0]);
            diceRolled = false;
            if(d!=6)
            {
                currentTurn=true;
                turnl.setIcon(turni[0]);
                
                if(killFlag==true)
                {
                    currentTurn=false;
                    turnl.setIcon(turni[1]);
                }
            }
            else
            {
                
            }
        }
    }
    
    public static boolean killByBlue(int color,int piece)
    {
        
        int killFlag=4;
        int gcolor=5;
        
        if(color==0)
        {
            for(int i=0;i<4;i++)
            {
                if(greenIsSafe[i]!=true)
                {
                    if(greenCurrent[i][2]==blueCurrent[piece][color])
                    {
                        killFlag=i;
                        gcolor=2;
                        break;
                    }
                }
            }
            
            
        }
        else if(color==1)
        {
            for(int i=0;i<4;i++)
            {
                if(greenIsSafe[i]!=true)
                {
                    if(greenCurrent[i][3]==blueCurrent[piece][color])
                    {
                        killFlag=i;
                        gcolor=3;
                        break;
                    }
                }
            }
        }
        else if(color==2)
        {
            for(int i=0;i<4;i++)
            {
                if(greenIsSafe[i]!=true)
                {
                    if(greenCurrent[i][0]==blueCurrent[piece][color])
                    {
                        killFlag=i;
                        gcolor=0;
                        break;
                    }
                }
            }
        }
        else if(color==3)
        {
            for(int i=0;i<4;i++)
            {
                if(greenIsSafe[i]!=true)
                {
                    if(greenCurrent[i][1]==blueCurrent[piece][color])
                    {
                        killFlag=i;
                        gcolor=1;
                        break;
                    }
                }
            }
        }
        
        if(killFlag!=4)
        {
            greenl[killFlag].setBounds(greenOriginX[killFlag],greenOriginY[killFlag],25,25);
            greenCurrent[killFlag][gcolor] = -1;
            
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public static boolean killByGreen(int color,int piece)
    {
        int killFlag=4;
        int bcolor=5;
        
        if(color==0)
        {
            for(int i=0;i<4;i++)
            {
                if(blueIsSafe[i]!=true)
                {
                    if(blueCurrent[i][2]==greenCurrent[piece][color])
                    {
                        killFlag=i;
                        bcolor=2;
                        break;
                    }
                }
            }
            
            
        }
        else if(color==1)
        {
            for(int i=0;i<4;i++)
            {
                if(blueIsSafe[i]!=true)
                {
                    if(blueCurrent[i][3]==greenCurrent[piece][color])
                    {
                        killFlag=i;
                        bcolor=3;
                        break;
                    }
                }
            }
        }
        else if(color==2)
        {
            for(int i=0;i<4;i++)
            {
                if(blueIsSafe[i]!=true)
                {
                    if(blueCurrent[i][0]==greenCurrent[piece][color])
                    {
                        killFlag=i;
                        bcolor=0;
                        break;
                    }
                }
            }
        }
        else if(color==3)
        {
            for(int i=0;i<4;i++)
            {
                if(blueIsSafe[i]!=true)
                {
                    if(blueCurrent[i][1]==greenCurrent[piece][color])
                    {
                        killFlag=i;
                        bcolor=1;
                        break;
                    }
                }
            }
        }
        
        if(killFlag!=4)
        {
            bluel[killFlag].setBounds(blueOriginX[killFlag],blueOriginY[killFlag],25,25);
            blueCurrent[killFlag][bcolor] = -1;
            
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public static int random()
    {
        Random r = new Random();
        
        int rand = 0;
        
        while(rand==0)
        {
            rand = r.nextInt(7);
        }
        
        return rand;
    }
    
    public static int checkPieceBlue(int x,int y)
    {
        int piece = 4;
        
        int color=-1,position=-1;
        
        for(int i=0;i<13;i++)
        {
            if(x>blueWayX[i] && x<(blueWayX[i]+50) && y>blueWayY[i] && y<(blueWayY[i]+50))
            {
                position=i;
                color=0;
                break;
            }
            else if(x>yellowWayX[i] && x<(yellowWayX[i]+50) && y>yellowWayY[i] && y<(yellowWayY[i]+50))
            {
                position=i;
                color=1;
                break;
            }
            else if(x>greenWayX[i] && x<(greenWayX[i]+50) && y>greenWayY[i] && y<(greenWayY[i]+50))
            {
                position=i;
                color=2;
                break;
            }
            else if(x>redWayX[i] && x<(redWayX[i]+50) && y>redWayY[i] && y<(redWayY[i]+50))
            {
                position=i;
                color=3;
                break;
            }
        }
        
        if(color!=-1 && position!=-1)
        {
            for(int i=0;i<4;i++)
            {
                if(blueCurrent[i][color]==position)
                {
                    piece=i;
                    break;
                }
            }
        }
        
        for(int i=0;i<4;i++)
        {
            if(x>blueOriginX[i] && x<(blueOriginX[i]+50) && y>blueOriginY[i] && y<(blueOriginY[i]+50))
            {
                piece=i;
            }
        }
        
        for(int i=0;i<6;i++)
        {
            if(x>450 && x<500 && y>blueWinWay[i] && y<(blueWinWay[i]+50))
            {
                color=4;
                position=i;
                break;
            }
        }
        //temp3.setText("color: "+color+"    position: "+position);
        if(color==4)
        {
            for(int i=0;i<4;i++)
            {
                if(blueCurrent[i][color]==position)
                {
                    piece=i;
                    break;
                }
            }
        }
        
        temp2.setText("piece: "+piece);
        return piece;
    }
    
    public static int checkPieceGreen(int x,int y)
    {
        int piece = 4;
        
        int color=-1,position=-1;
        
        for(int i=0;i<13;i++)
        {
            if(x>blueWayX[i] && x<(blueWayX[i]+50) && y>blueWayY[i] && y<(blueWayY[i]+50))
            {
                position=i;
                color=2;
                break;
            }
            else if(x>yellowWayX[i] && x<(yellowWayX[i]+50) && y>yellowWayY[i] && y<(yellowWayY[i]+50))
            {
                position=i;
                color=3;
                break;
            }
            else if(x>greenWayX[i] && x<(greenWayX[i]+50) && y>greenWayY[i] && y<(greenWayY[i]+50))
            {
                position=i;
                color=0;
                break;
            }
            else if(x>redWayX[i] && x<(redWayX[i]+50) && y>redWayY[i] && y<(redWayY[i]+50))
            {
                position=i;
                color=1;
                break;
            }
        }
        
        if(color!=-1 && position!=-1)
        {
            for(int i=0;i<4;i++)
            {
                if(greenCurrent[i][color]==position)
                {
                    piece=i;
                    break;
                }
            }
        }
        
        for(int i=0;i<4;i++)
        {
            if(x>greenOriginX[i] && x<(greenOriginX[i]+50) && y>greenOriginY[i] && y<(greenOriginY[i]+50))
            {
                piece=i;
            }
        }
        
        for(int i=0;i<6;i++)
        {
            if(x>450 && x<500 && y>greenWinWay[i] && y<(greenWinWay[i]+50))
            {
                color=4;
                position=i;
                break;
            }
        }
        //temp3.setText("color: "+color+"    position: "+position);
        if(color==4)
        {
            for(int i=0;i<4;i++)
            {
                if(greenCurrent[i][color]==position)
                {
                    piece=i;
                    break;
                }
            }
        }
        
        temp2.setText("piece: "+piece);
        return piece;
    }
    
    public static void roll()
    {
        
        boolean tempFlag=true;
        
        dice=random();
        
        
        
        dicel.setIcon(dicei[dice-1]);
        
        
        if(currentTurn==true)
        {
            if(dice==6)
            {
                statusl.setIcon(statusi[2]);
                diceRolled=true;
            }
            else
            {
                for(int i=0;i<4;i++)
                {
                    if(blueIsMovable[i]==true)
                    {
                        tempFlag=false;
                        break;
                    }
                }
                if(tempFlag==true)
                {
                    turnl.setIcon(turni[1]);
                    currentTurn=false;
                }
                else
                {
                    statusl.setIcon(statusi[2]);
                    diceRolled=true;
                }
            }
        }
        else
        {
            if(dice==6)
            {
                statusl.setIcon(statusi[2]);
                diceRolled=true;
            }
            else
            {
                for(int i=0;i<4;i++)
                {
                    if(greenIsMovable[i]==true)
                    {
                        tempFlag=false;
                        break;
                    }
                }
                if(tempFlag==true)
                {
                    turnl.setIcon(turni[0]);
                    currentTurn=true;
                }
                else
                {
                    statusl.setIcon(statusi[2]);
                    diceRolled=true;
                }
            }
        }
        
        
    }
    
    public static void delay()
    {
        try
        {
            Thread.sleep(1000);
        }
        catch(Exception e)
        {}
    }

    
    public static void main(String[] args) 
    {
        Ludo l = new Ludo();
    }

    @Override
    public void mouseClicked(MouseEvent e) 
    {
        int x = e.getX()-xBuffer;
        int y = e.getY()-yBuffer;
        
        temp1.setText("x:"+x+"     y:"+y);
        
        //roll();
        if(diceRolled==false)
        {
            if(x>900 && x<1100 && y>500 && y<600)
            {
                roll();
            }
        }
        else
        {
            if(currentTurn==true)
            {
                int piece = checkPieceBlue(x,y);
                moveBlue(dice,piece);
            }
            else
            {
                int piece = checkPieceGreen(x,y);
                moveGreen(dice,piece);
            }
            
        }
    }

    @Override
    public void mousePressed(MouseEvent e) 
    {}

    @Override
    public void mouseReleased(MouseEvent e) 
    {}

    @Override
    public void mouseEntered(MouseEvent e) 
    {}

    @Override
    public void mouseExited(MouseEvent e) 
    {}
    
}
